# G.E. ZARARSIZ
# Packages to be installed.
pkgs.to.install <- c("ggplot2", "lattice", "caret", "doParallel", "magrittr", "pls", "grid")

# Install CRAN packages
install.packages(pkgs.to.install)
